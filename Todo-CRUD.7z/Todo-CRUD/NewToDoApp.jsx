import { useEffect, useReducer } from "react";
import "./styles.css";

const initialState = {
  todos: (() => {
    const savedTodos = localStorage.getItem("todos");
    if (savedTodos) {
      return JSON.parse(savedTodos);
    } else {
      return [];
    }
  })(),
  todo: "",
  isEditing: false,
  currentTodo: {},
};

function reducer(state, action) {
  switch (action.type) {
    case "ADD_TODO":
      return {
        ...state,
        todos: [
          ...state.todos,
          {
            id: state.todos.length + 1,
            text: state.todo.trim(),
          },
        ],
        todo: "",
      };
    case "DELETE_TODO":
      return {
        ...state,
        todos: state.todos.filter((todo) => todo.id !== action.payload),
      };
    case "UPDATE_TODO":
      return {
        ...state,
        todos: state.todos.map((todo) =>
          todo.id === action.payload.id ? action.payload.updatedTodo : todo
        ),
        isEditing: false,
        currentTodo: {},
      };
    case "SET_TODO":
      return {
        ...state,
        todo: action.payload,
      };
    case "SET_IS_EDITING":
      return {
        ...state,
        isEditing: action.payload,
      };
    case "SET_CURRENT_TODO":
      return {
        ...state,
        currentTodo: action.payload,
      };
    default:
      return state;
  }
}

export default function App() {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    localStorage.setItem("todos", JSON.stringify(state.todos));
  }, [state.todos]);

  function handleInputChange(e) {
    dispatch({ type: "SET_TODO", payload: e.target.value });
  }

  function handleEditInputChange(e) {
    dispatch({
      type: "SET_CURRENT_TODO",
      payload: { ...state.currentTodo, text: e.target.value },
    });
  }

  function handleFormSubmit(e) {
    e.preventDefault();
    if (state.todo !== "") {
      dispatch({ type: "ADD_TODO" });
    }
  }

  function handleEditFormSubmit(e) {
    e.preventDefault();
    dispatch({
      type: "UPDATE_TODO",
      payload: { id: state.currentTodo.id, updatedTodo: state.currentTodo },
    });
  }

  function handleDeleteClick(id) {
    dispatch({ type: "DELETE_TODO", payload: id });
  }

  function handleEditClick(todo) {
    dispatch({ type: "SET_IS_EDITING", payload: true });
    dispatch({ type: "SET_CURRENT_TODO", payload: todo });
  }

  return (
    <div className="App">
      {state.isEditing ? (
        <form onSubmit={handleEditFormSubmit}>
          <h2>Edit Todo</h2>
          <label htmlFor="editTodo">Edit todo: </label>
          <input
            name="editTodo"
            type="text"
            placeholder="Edit todo"
            value={state.currentTodo.text}
            onChange={handleEditInputChange}
          />
          <button type="submit">Update</button>
          <button onClick={() => dispatch({ type: "SET_IS_EDITING", payload: false })}>
            Cancel
          </button>
        </form>
      ) : (
        <form onSubmit={handleFormSubmit}>
          <h2>Add Todo</h2>
          <label htmlFor="todo">Add todo: </label>
          <input
            name="todo"
            type="text"
            placeholder="Create a new todo"      value={state.todo}
            onChange={handleInputChange}
          />
          <button type="submit">Add</button>
        </form>
        )}
        <div className="todos">
          <h2>Todos</h2>
          {state.todos.length > 0 ? (
            <ul>
              {state.todos.map((todo) => (
                <li key={todo.id}>
                  <span>{todo.text}</span>
                  <div>
                    <button onClick={() => handleEditClick(todo)}>Edit</button>
                    <button onClick={() => handleDeleteClick(todo.id)}>Delete</button>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p>No todos yet.</p>
          )}
        </div>
      </div>
      );
    }
